import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui'; // Untuk BackdropFilter (efek glassmorphism jika diperlukan)

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> userList = [];
  late TabController _tabController;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String selectedRole = 'member';

  bool _isLoadingList = false;
  bool _isLoadingAction = false;

  // -- COLORS (Sama seperti halaman sebelumnya) --
  final Color _primaryAccent = const Color(0xFFD500F9);
  final Color _bgTop = const Color(0xFF2E004B);
  final Color _bgBottom = const Color(0xFF0F001A);
  final Color _cardBg = const Color(0xFF1A0B2E).withOpacity(0.8);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _tabController = TabController(length: 2, vsync: this);
    _fetchUsers();
  }

  @override
  void dispose() {
    _tabController.dispose();
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    if (!mounted) return;
    setState(() => _isLoadingList = true);
    try {
      final res = await http.get(
        Uri.parse('http://hcr-1.heppyhost.my.id:25583/listUsers?key=$sessionKey'),
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        if (mounted) {
          setState(() {
            userList = data['users'] ?? [];
          });
        }
      } else {
        _showDialog("⚠️ Error", data['message'] ?? 'Unauthorized access to user list.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Failed to load user list.");
    }
    if (mounted) setState(() => _isLoadingList = false);
  }

  Future<void> _deleteUser(String usernameToDelete) async {
    if (usernameToDelete.isEmpty) {
      _showDialog("⚠️ Error", "Please enter username to delete.");
      return;
    }

    // Konfirmasi hapus
    bool confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _bgTop,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20), side: BorderSide(color: _primaryAccent.withOpacity(0.5))),
        title: Text("Confirm Delete",
            style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        content: Text("Are you sure you want to delete user '$usernameToDelete'?",
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("CANCEL", style: TextStyle(color: Colors.white54))),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("DELETE", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold))),
        ],
      ),
    ) ?? false;

    if (!confirm) return;

    setState(() => _isLoadingAction = true);
    try {
      final res = await http.get(
        Uri.parse('http://hcr-1.heppyhost.my.id:25583/deleteUser?key=$sessionKey&username=$usernameToDelete'),
      ).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showDialog("✅ Success", "User '${data['user']['username']}' deleted successfully.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _showDialog("❌ Failed", data['message'] ?? 'Failed to delete user.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Failed to connect to server.");
    }
    if (mounted) setState(() => _isLoadingAction = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _showDialog("⚠️ Error", "All fields are required.");
      return;
    }

    setState(() => _isLoadingAction = true);
    try {
      final url = Uri.parse(
          'http://hcr-1.heppyhost.my.id:25583/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$selectedRole');
      final res = await http.get(url).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showDialog("✅ Success", "Account '${data['user']['username']}' created successfully.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => selectedRole = 'member');
        _fetchUsers();
        _tabController.animateTo(0); // Pindah ke tab list setelah sukses
      } else {
        _showDialog("❌ Failed", data['message'] ?? 'Failed to create account.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Failed to connect to server.");
    }
    if (mounted) setState(() => _isLoadingAction = false);
  }

  void _showDialog(String title, String message) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _bgTop,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20), side: BorderSide(color: _primaryAccent.withOpacity(0.5))),
        title: Text(title,
            style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        content: Text(message, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  // --- WIDGETS TAMPILAN ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("ADMIN CONTROL",
            style: TextStyle(
                fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5, color: _primaryAccent)),
        backgroundColor: _bgTop.withOpacity(0.5), // Sedikit transparan
        elevation: 0,
        iconTheme: IconThemeData(color: _primaryAccent),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: _primaryAccent,
          indicatorWeight: 3,
          labelColor: _primaryAccent,
          unselectedLabelColor: Colors.white54,
          labelStyle: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12),
          tabs: const [
            Tab(icon: Icon(Icons.list_alt_rounded), text: "USER LIST"),
            Tab(icon: Icon(Icons.person_add_alt_1_rounded), text: "CREATE NEW"),
          ],
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [_bgTop, _bgBottom], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildUserListTab(),
              _buildCreateUserTab(),
            ],
          ),
        ),
      ),
    );
  }

  // --- TAB 1: USER LIST ---
  Widget _buildUserListTab() {
    return RefreshIndicator(
      onRefresh: _fetchUsers,
      color: _primaryAccent,
      backgroundColor: _bgTop,
      child: SingleChildScrollView( // Gunakan SingleChildScrollView agar bisa scroll keseluruhan
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildDeleteSection(), // Quick delete di atas list
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("ALL USERS (${userList.length})",
                    style: TextStyle(
                        color: _primaryAccent, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.bold)),
                if (_isLoadingList)
                  SizedBox(height: 15, width: 15, child: CircularProgressIndicator(color: _primaryAccent, strokeWidth: 2))
              ],
            ),
            const SizedBox(height: 15),
            if (userList.isEmpty && !_isLoadingList)
               Padding(
                 padding: const EdgeInsets.only(top: 50),
                 child: Text("No users found.", style: TextStyle(color: Colors.white54)),
               )
            else
              ListView.builder(
                shrinkWrap: true, // Agar tidak conflict dengan SingleChildScrollView
                physics: const NeverScrollableScrollPhysics(), // Scroll dihandle oleh SingleChildScrollView induk
                itemCount: userList.length,
                itemBuilder: (context, index) => _buildUserCard(userList[index]),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeleteSection() {
    return _glassContainer(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.delete_sweep_outlined, color: Colors.redAccent, size: 24),
              const SizedBox(width: 10),
              Text("QUICK DELETE",
                  style: TextStyle(color: Colors.redAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(
                child: _buildInput("Enter Username to delete", deleteController, Icons.person_remove_outlined, isDense: true),
              ),
              const SizedBox(width: 10),
              InkWell(
                onTap: _isLoadingAction ? null : () => _deleteUser(deleteController.text.trim()),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.redAccent.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
                  ),
                  child: _isLoadingAction && deleteController.text.isNotEmpty
                      ? SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.redAccent, strokeWidth: 2))
                      : Icon(Icons.delete_forever_rounded, color: Colors.redAccent),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUserCard(dynamic user) {
    Color roleColor = _primaryAccent;
    IconData roleIcon = Icons.person_outline;
    if (user['role'] == 'admin' || user['role'] == 'owner') {
      roleColor = Colors.redAccent;
      roleIcon = Icons.admin_panel_settings_outlined;
    } else if (user['role'] == 'reseller') {
      roleColor = Colors.greenAccent;
      roleIcon = Icons.storefront_outlined;
    } else if (user['role'] == 'vip') {
      roleColor = Colors.amberAccent;
      roleIcon = Icons.star_outline;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: roleColor.withOpacity(0.3), width: 1),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        leading: CircleAvatar(
          backgroundColor: roleColor.withOpacity(0.1),
          child: Icon(roleIcon, color: roleColor),
        ),
        title: Text(user['username'],
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Row(
          children: [
            Icon(Icons.timer_outlined, size: 14, color: Colors.white54),
            const SizedBox(width: 4),
            Text("${user['expiredDate']}", style: const TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                  color: roleColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: roleColor.withOpacity(0.3))),
              child: Text(user['role'].toUpperCase(),
                  style: TextStyle(color: roleColor, fontSize: 10, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.white38),
          onPressed: () => _deleteUser(user['username']),
          tooltip: "Delete User",
        ),
      ),
    );
  }

  // --- TAB 2: CREATE USER ---
  Widget _buildCreateUserTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(25),
      child: Column(
        children: [
          _glassContainer(
            padding: const EdgeInsets.all(25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("NEW USER DETAILS",
                    style: TextStyle(
                        color: _primaryAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 25),
                _buildInput("Username", createUsernameController, Icons.person_outline),
                const SizedBox(height: 15),
                _buildInput("Password", createPasswordController, Icons.lock_outline),
                const SizedBox(height: 15),
                Row(
                  children: [
                    Expanded(
                        flex: 5,
                        child: _buildInput("Duration (Days)", createDayController, Icons.calendar_today_outlined,
                            type: TextInputType.number)),
                    const SizedBox(width: 15),
                    Expanded(
                      flex: 4,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: _primaryAccent.withOpacity(0.5)),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedRole,
                            dropdownColor: _bgTop,
                            isExpanded: true,
                            icon: Icon(Icons.arrow_drop_down, color: _primaryAccent),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            items: ['member', 'reseller', 'vip'].map((role) {
                              return DropdownMenuItem(value: role, child: Text(role.toUpperCase(), style: TextStyle(fontSize: 13)));
                            }).toList(),
                            onChanged: (val) => setState(() => selectedRole = val!),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 40),
                _buildGradientButton(
                  onPressed: _isLoadingAction ? null : _createAccount,
                  text: "CREATE ACCOUNT",
                  icon: Icons.person_add_alt_1,
                  isLoading: _isLoadingAction && createUsernameController.text.isNotEmpty,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- HELPER WIDGETS ---
  Widget _glassContainer({required Widget child, EdgeInsetsGeometry? padding}) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _primaryAccent.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 8)),
        ],
      ),
      child: child,
    );
  }

  Widget _buildInput(String hint, TextEditingController controller, IconData icon,
      {TextInputType type = TextInputType.text, bool isDense = false}) {
    return TextField(
      controller: controller,
      keyboardType: type,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        isDense: isDense,
        prefixIcon: Icon(icon, color: _primaryAccent.withOpacity(0.7), size: 22),
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
        filled: true,
        fillColor: Colors.black.withOpacity(0.3),
        contentPadding: EdgeInsets.symmetric(vertical: isDense ? 14 : 18, horizontal: 15),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: Colors.white.withOpacity(0.1))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: _primaryAccent, width: 1.5)),
      ),
    );
  }

  Widget _buildGradientButton(
      {required VoidCallback? onPressed,
      required String text,
      required IconData icon,
      required bool isLoading}) {
    return Container(
      width: double.infinity,
      height: 55,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        gradient: LinearGradient(colors: [_primaryAccent, _primaryAccent.withOpacity(0.6)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        boxShadow: [BoxShadow(color: _primaryAccent.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
        child: isLoading
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white),
                  const SizedBox(width: 10),
                  Text(text,
                      style: const TextStyle(
                          color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                ],
              ),
      ),
    );
  }
}