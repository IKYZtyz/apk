import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _newUserController = TextEditingController();
  final _newPassController = TextEditingController();
  final _dayController = TextEditingController();

  final _editUserController = TextEditingController();
  final _editDayController = TextEditingController();

  bool _isLoadingCreate = false;
  bool _isLoadingEdit = false;

  // -- COLORS --
  final Color _primaryAccent = const Color(0xFFD500F9);
  final Color _bgTop = const Color(0xFF2E004B);
  final Color _bgBottom = const Color(0xFF0F001A);
  final Color _cardBg = const Color(0xFF1A0B2E).withOpacity(0.8);

  Future<void> _createAccount() async {
    final newUser = _newUserController.text.trim();
    final newPass = _newPassController.text.trim();
    final days = _dayController.text.trim();

    if (newUser.isEmpty || newPass.isEmpty || days.isEmpty) {
      _showDialog("⚠️ Error", "Semua field harus diisi.");
      return;
    }

    setState(() => _isLoadingCreate = true);

    final uri = Uri.parse(
      'http://hcr-1.heppyhost.my.id:25583/createAccount?key=${widget.keyToken}&newUser=$newUser&pass=$newPass&day=$days',
    );

    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showDialog("✅ Success", "Akun berhasil dibuat!");
        _newUserController.clear();
        _newPassController.clear();
        _dayController.clear();
      } else {
        _showDialog("❌ Failed", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Tidak dapat terhubung ke server.");
    }

    if (mounted) setState(() => _isLoadingCreate = false);
  }

  Future<void> _editDuration() async {
    final username = _editUserController.text.trim();
    final newDays = _editDayController.text.trim();

    if (username.isEmpty || newDays.isEmpty) {
      _showDialog("⚠️ Error", "Isi username dan durasi.");
      return;
    }

    setState(() => _isLoadingEdit = true);

    final uri = Uri.parse(
      'http://hcr-1.heppyhost.my.id:25583/editUser?key=${widget.keyToken}&username=$username&addDays=$newDays',
    );

    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _showDialog("✅ Success", "Durasi berhasil diperbarui.");
        _editUserController.clear();
        _editDayController.clear();
      } else {
        _showDialog("❌ Gagal", data['message'] ?? 'Gagal memperbarui durasi.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Tidak dapat menghubungi server.");
    }

    if (mounted) setState(() => _isLoadingEdit = false);
  }

  void _showDialog(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _bgTop,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: _primaryAccent.withOpacity(0.5))),
        title: Text(title,
            style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // Helper widget untuk glass container
  Widget _glassContainer({required Widget child, EdgeInsetsGeometry? padding}) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: _primaryAccent.withOpacity(0.3), width: 1),
         boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
      ),
      child: child,
    );
  }

  // Widget Input yang sudah di-style
  Widget _buildInput(String hint, TextEditingController controller, IconData icon, {TextInputType type = TextInputType.text}) {
    return _glassContainer(
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
          prefixIcon: Icon(icon, color: _primaryAccent),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        ),
      ),
    );
  }

  // Widget Tombol yang sudah di-style
  Widget _buildGradientButton({
    required VoidCallback? onPressed,
    required String text,
    required IconData icon,
    required bool isLoading,
  }) {
    return Container(
      height: 55,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        gradient: LinearGradient(
          colors: [_primaryAccent, _primaryAccent.withOpacity(0.6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: _primaryAccent.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 5))
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
        child: isLoading
            ? const SizedBox(height: 25, width: 25, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white),
                  const SizedBox(width: 10),
                  Text(
                    text,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
  
  // Helper untuk label section
  Widget _sectionTitle(String title) {
     return Text(
      title,
      style: TextStyle(
        color: _primaryAccent,
        fontSize: 18,
        fontFamily: 'Orbitron',
        letterSpacing: 1.2,
        fontWeight: FontWeight.bold
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("RESELLER MENU",
            style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: _primaryAccent)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: _primaryAccent),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_bgTop, _bgBottom],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _sectionTitle("Create New Account"),
                const SizedBox(height: 20),
                _buildInput("New Username", _newUserController, Icons.person_add_outlined),
                const SizedBox(height: 16),
                _buildInput("New Password", _newPassController, Icons.lock_outline),
                const SizedBox(height: 16),
                _buildInput("Duration (days)", _dayController, Icons.calendar_today_outlined, type: TextInputType.number),
                const SizedBox(height: 30),
                _buildGradientButton(
                  onPressed: _isLoadingCreate ? null : _createAccount,
                  text: "CREATE ACCOUNT",
                  icon: Icons.add_circle_outline,
                  isLoading: _isLoadingCreate,
                ),
                const SizedBox(height: 40),
                Divider(color: _primaryAccent.withOpacity(0.3), thickness: 1),
                const SizedBox(height: 30),
                _sectionTitle("Edit Account Duration"),
                const SizedBox(height: 20),
                _buildInput("Target Username", _editUserController, Icons.person_search_outlined),
                const SizedBox(height: 16),
                _buildInput("Add Duration (days)", _editDayController, Icons.update_outlined, type: TextInputType.number),
                const SizedBox(height: 30),
                _buildGradientButton(
                  onPressed: _isLoadingEdit ? null : _editDuration,
                  text: "UPDATE DURATION",
                  icon: Icons.edit_calendar_outlined,
                  isLoading: _isLoadingEdit,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}