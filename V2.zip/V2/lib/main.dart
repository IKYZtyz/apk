import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // Warna Tema Global
  static final Color _primaryAccent = const Color(0xFFD500F9);
  static final Color _bgDark = const Color(0xFF0F001A);
  static final Color _cardSurface = const Color(0xFF1A0B2E);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Systemcrasher',

      // --- PERBAIKAN DI SINI ---
      // scrollBehavior dipindahkan ke MaterialApp, bukan di dalam ThemeData
      scrollBehavior: const MaterialScrollBehavior().copyWith(
        physics: const BouncingScrollPhysics(), // Efek pantul (overscroll) yang terasa cepat & modern
      ),

      // --- THEME CONFIG ---
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        fontFamily: 'Orbitron',
        scaffoldBackgroundColor: _bgDark,
        primaryColor: _primaryAccent,
        colorScheme: ColorScheme.dark(
          primary: _primaryAccent,
          secondary: _primaryAccent,
          surface: _cardSurface,
          onPrimary: Colors.white,
          onSurface: Colors.white,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          iconTheme: IconThemeData(color: _primaryAccent),
          titleTextStyle: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 1.5,
            color: _primaryAccent,
          ),
        ),
      ),

      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return _pageRoute(const LoginPage());

          case '/loader':
            final args = settings.arguments as Map<String, dynamic>;
            return _pageRoute(LoaderPage(
              username: args['username'],
              password: args['password'],
              role: args['role'],
              sessionKey: args['key'],
              expiredDate: args['expiredDate'],
              listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
            ));

          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return _pageRoute(HomePage(
              username: args['username'],
              password: args['password'],
              listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
              role: args['role'],
              expiredDate: args['expiredDate'],
              sessionKey: args['sessionKey'],
            ));

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return _pageRoute(SellerPage(
              keyToken: args['keyToken'],
            ));

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return _pageRoute(AdminPage(
              sessionKey: args['sessionKey'],
            ));

          default:
            return _pageRoute(const Scaffold(
              body: Center(child: Text("404 - Not Found", style: TextStyle(color: Colors.white))),
            ));
        }
      },
    );
  }

  PageRoute _pageRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeOutQuart;

        var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        return SlideTransition(position: animation.drive(tween), child: child);
      },
    );
  }
}