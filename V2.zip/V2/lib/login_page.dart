import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;

  // -- COLORS --
  // Mendefinisikan warna tema agar mudah diubah
  final Color _primaryAccent = const Color(0xFFD500F9); // Ungu Neon Cerah
  final Color _bgTop = const Color(0xFF2E004B); // Ungu Gelap Atas
  final Color _bgBottom = const Color(0xFF0F001A); // Hampir Hitam Bawah
  final Color _inputFill = const Color(0xFF4A0072).withOpacity(0.3); // Transparan ungu

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      // Tip: Sebaiknya gunakan timeout agar tidak loading selamanya jika server down
      final validate = await http.post(
        Uri.parse("http://hcr-1.heppyhost.my.id:25583/validate"),
        body: {
          "username": username,
          "password": password,
        },
      ).timeout(const Duration(seconds: 15));

      if (validate.statusCode == 200) {
        final validData = jsonDecode(validate.body);
        print("VALIDATE RESPONSE => $validData");

        if (validData['expired'] == true) {
          _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
        } else if (validData['valid'] != true) {
          _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
        } else {
          final myInfoRes = await http.get(Uri.parse(
                  "http://hcr-1.heppyhost.my.id:25583/myInfo?username=$username&password=$password"))
              .timeout(const Duration(seconds: 15));
              
          final info = jsonDecode(myInfoRes.body);
          print("MY INFO => $info");

          if (info['valid'] != true) {
            _showAlert("⚠️ Error", "Key fetch failed.");
            return;
          }

          if (mounted) {
            Navigator.pushNamed(
              context,
              '/loader',
              arguments: {
                'username': username,
                'password': password,
                'role': info['role'],
                'key': info['key'],
                'expiredDate': info['expiredDate'],
                'listBug': info['listBug'] ?? [],
              },
            );
          }
        }
      } else {
         _showAlert("⚠️ Server Error", "Server returned status ${validate.statusCode}");
      }
    } catch (e) {
      print("Login Error: $e");
      _showAlert("🌐 Connection Error", "Failed to connect to the server.\nCheck your internet connection.");
    }

    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A0B2E), // Background dialog ungu gelap
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _primaryAccent.withOpacity(0.3), width: 1),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: _primaryAccent,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 16,
            height: 1.4,
          ),
        ),
        actions: [
          if (showContact)
            TextButton.icon(
              icon: const Icon(Icons.telegram, color: Colors.blueAccent),
              label: const Text("Contact Admin", style: TextStyle(color: Colors.blueAccent)),
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=OrzaaSystem");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/OrzaaSystem"),
                      mode: LaunchMode.externalApplication);
                }
              },
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "CLOSE",
              style: TextStyle(
                color: _primaryAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Menggunakan MediaQuery untuk responsive sizing
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_bgTop, _bgBottom],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // --- LOGO SECTION ---
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _primaryAccent.withOpacity(0.2),
                        blurRadius: 30,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/logo.jpg',
                      height: 180, // Sedikit diperkecil agar proporsional
                      width: 180,
                      fit: BoxFit.cover,
                      // Tambahkan error builder jika logo gagal load
                      errorBuilder: (context, error, stackTrace) => 
                        Icon(Icons.security, size: 100, color: _primaryAccent),
                    ),
                  ),
                ),
                const SizedBox(height: 25),
                Text(
                  "Welcome Back",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(color: _primaryAccent.withOpacity(0.5), blurRadius: 10)
                    ]
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Sign in to continue",
                  style: TextStyle(
                    color: _primaryAccent.withOpacity(0.7),
                    fontSize: 14,
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 50),

                // --- FORM SECTION ---
                _modernInput("Username", userController, Icons.person_outline),
                const SizedBox(height: 20),
                _modernInput("Password", passController, Icons.lock_outline, isPassword: true),
                
                const SizedBox(height: 40),

                // --- LOGIN BUTTON ---
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: double.infinity, // Full width button
                  height: 55,
                  child: ElevatedButton(
                    onPressed: isLoading ? null : login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _primaryAccent,
                      foregroundColor: Colors.white,
                      shadowColor: _primaryAccent.withOpacity(0.6),
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: isLoading
                        ? const SizedBox(
                            height: 25,
                            width: 25,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                          )
                        : const Text(
                            "Sign In",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _modernInput(String hint, TextEditingController controller, IconData icon,
      {bool isPassword = false}) {
    return Container(
      decoration: BoxDecoration(
        color: _inputFill,
        borderRadius: BorderRadius.circular(16),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
        cursorColor: _primaryAccent,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
          prefixIcon: Icon(icon, color: _primaryAccent.withOpacity(0.8)),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          enabledBorder: OutlineInputBorder(
             borderRadius: BorderRadius.circular(16),
             borderSide: BorderSide(color: Colors.transparent),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: _primaryAccent, width: 1.5),
          ),
        ),
      ),
    );
  }
}