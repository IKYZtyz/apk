import 'package:flutter/material.dart';
import 'home_page.dart';
import 'admin_page.dart';
import 'seller_page.dart';

class LoaderPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<dynamic> listBug; // Tipe data yang fleksibel untuk menerima respon JSON

  const LoaderPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.sessionKey,
  });

  @override
  State<LoaderPage> createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeScaleAnim;

  // -- COLORS --
  final Color _primaryAccent = const Color(0xFFD500F9);
  final Color _bgTop = const Color(0xFF2E004B);
  final Color _bgBottom = const Color(0xFF0F001A);
  final Color _cardBg = const Color(0xFF1A0B2E).withOpacity(0.8);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeScaleAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _calculateAccountAge() {
    try {
      final expired = DateTime.parse(widget.expiredDate);
      final now = DateTime.now();
      final age = expired.difference(now).inDays;
      return age > 0 ? "$age days remaining" : "Expired";
    } catch (_) {
      return "Unknown";
    }
  }

  Route _smoothPageTransition(Widget page) {
    return PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeInOut;
        var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        var offsetAnimation = animation.drive(tween);
        return SlideTransition(position: offsetAnimation, child: child);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("DASHBOARD",
            style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: _primaryAccent)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: _primaryAccent),
      ),
      drawer: _buildDrawer(),
      body: Container(
        // --- PERBAIKAN 1: Memastikan background mengisi seluruh layar ---
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_bgTop, _bgBottom],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: _buildMyInfo(),
        ),
      ),
    );
  }

  Widget _buildMyInfo() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ScaleTransition(
            scale: _fadeScaleAnim,
            child: FadeTransition(
              opacity: _controller,
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _primaryAccent.withOpacity(0.3),
                      blurRadius: 25,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.transparent,
                  backgroundImage: const AssetImage('assets/images/logo.jpg'),
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),
          FadeTransition(
            opacity: _controller,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                color: _cardBg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _primaryAccent.withOpacity(0.3), width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 15,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _infoRow(Icons.person_outline, "Username", widget.username),
                  _divider(),
                  _infoRow(Icons.shield_outlined, "Role", widget.role.toUpperCase()),
                  _divider(),
                  _infoRow(Icons.timer_outlined, "Expired", widget.expiredDate.split(" ")[0]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 25),
          Row(
            children: [
              Expanded(child: _statCard("Status", "ACTIVE", Icons.check_circle_outline, Colors.greenAccent)),
              const SizedBox(width: 15),
              Expanded(child: _statCard("Days Left", _calculateAccountAge().split(" ")[0], Icons.calendar_today_outlined, Colors.orangeAccent)),
            ],
          ),
          const SizedBox(height: 15),
          _statCard("Session Key", "${widget.sessionKey.substring(0, 8)}...", Icons.vpn_key_outlined, Colors.blueAccent, isFullWidth: true),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Icon(icon, color: _primaryAccent, size: 26),
          const SizedBox(width: 15),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 16)),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _divider() {
    return Divider(color: _primaryAccent.withOpacity(0.15), height: 1, thickness: 1);
  }

  Widget _statCard(String title, String value, IconData icon, Color accentColor, {bool isFullWidth = false}) {
    return Container(
      width: isFullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: accentColor, size: 28),
          const SizedBox(height: 15),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 5),
          Text(
            title,
            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_bgTop, Colors.black],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.2),
                border: Border(bottom: BorderSide(color: _primaryAccent.withOpacity(0.2))),
              ),
              // --- PERBAIKAN 2a: Menyesuaikan padding header ---
              padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(2), // Sedikit kurangi padding border
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: _primaryAccent, width: 2),
                    ),
                    child: CircleAvatar(
                      radius: 28, // Sedikit kurangi ukuran avatar agar muat
                      backgroundImage: const AssetImage('assets/images/logo.jpg'),
                    ),
                  ),
                  // --- PERBAIKAN 2b: Mengurangi jarak vertikal ---
                  const SizedBox(height: 10), 
                  Text(
                    "Systemcrasher",
                    style: TextStyle(
                        fontSize: 18, // Sedikit kurangi ukuran font header
                        fontFamily: 'Orbitron',
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2),
                  ),
                  Text(
                    "Welcome, ${widget.username}",
                    style: TextStyle(color: _primaryAccent.withOpacity(0.8), fontSize: 14),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            _drawerItem(Icons.dashboard_outlined, "Dashboard", onTap: () => Navigator.pop(context)),
            _drawerItem(Icons.bug_report_outlined, "Attack Menu", onTap: () {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  _smoothPageTransition(HomePage(
                    username: widget.username,
                    password: widget.password,
                    // Konversi aman dari List<dynamic> ke List<Map<String, dynamic>>
                    listBug: List<Map<String, dynamic>>.from(widget.listBug),
                    role: widget.role,
                    expiredDate: widget.expiredDate,
                    sessionKey: widget.sessionKey,
                  )));
            }),
            if (['reseller', 'owner', 'reseller1'].contains(widget.role.toLowerCase()))
              _drawerItem(Icons.people_outline, "Reseller Menu", onTap: () {
                Navigator.pop(context);
                Navigator.push(context, _smoothPageTransition(SellerPage(keyToken: widget.sessionKey)));
              }),
            if (widget.role.toLowerCase() == 'owner')
              _drawerItem(Icons.admin_panel_settings_outlined, "Admin Control", onTap: () {
                Navigator.pop(context);
                Navigator.push(context, _smoothPageTransition(AdminPage(sessionKey: widget.sessionKey)));
              }),
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Divider(color: Colors.white.withOpacity(0.1)),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("CREDITS",
                      style: TextStyle(
                          color: Colors.white54, fontFamily: 'Orbitron', fontSize: 12, letterSpacing: 1.5)),
                  const SizedBox(height: 10),
                  _creditText("@OrzaaSystem < Owner >"),
                  _creditText("@Zyrexoffc3 < Co Owner >"),
                  _creditText("@matzzxz < Developer >"),
                  const SizedBox(height: 15),
                  Text("© 2025 All rights reserved.",
                      style: TextStyle(color: _primaryAccent.withOpacity(0.5), fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, {required VoidCallback onTap}) {
    return ListTile(
      leading: Icon(icon, color: Colors.white70),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16)),
      onTap: onTap,
      hoverColor: _primaryAccent.withOpacity(0.1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
    );
  }

  Widget _creditText(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(text, style: const TextStyle(color: Colors.white38, fontSize: 13)),
    );
  }
}