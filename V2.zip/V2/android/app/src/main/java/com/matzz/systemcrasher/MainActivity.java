package com.matzz.systemcrasher;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
